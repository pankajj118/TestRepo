package readdata.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import java.util.List;

import jmh.java.name.velikodniy.vitaliy.fixedlength.benchmark.FixedLengthBenchStream;

import name.velikodniy.vitaliy.fixedlength.FixedLength;

public class TestClass {
    public TestClass() {
        super();

    }

    public static void main(String args[]) {
        InputStream stream;

        //  stream = new FileInputStream(new File("C:\\Users\\pankajj\\Desktop\\sampleMixed"));

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\pankajj\\Desktop\\sampleMixed"))) {
            String line;
            while ((line = br.readLine()) != null) {
                stream = new FixedLengthBenchStream(line, 1);
                //   System.out.println(line);
                List<Object> parse = new FixedLength().registerLineType(Employee.class)
                                                      .registerLineType(Employee1.class)
                                                      .parse(stream);
                //  System.out.println("listcount"+parse.size());
                parse.forEach((t) -> {
                    if (parse.get(0) instanceof Employee) {
                        Employee abTest = (Employee) t;
                        System.out.println(abTest.firstName + abTest.lastName);
                    } else if (parse.get(0) instanceof Employee1) {
                        Employee1 abTest1 = (Employee1) t;
                        System.out.println(abTest1.Name + abTest1.lastName);
                    }

                });
            }
        } catch (IOException e) {
        }
        finally {
        }


    }
}

